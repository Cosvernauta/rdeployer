#if 0
	shc Version 4.0.3, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -f xmlUtil3 -o xmlUtil3.io 
#endif

static  char data [] = 
#define      msg2_z	19
#define      msg2	((&data[3]))
	"\161\276\015\033\107\001\175\143\213\362\021\307\237\107\261\137"
	"\053\312\234\163\234\327\137\275"
#define      msg1_z	65
#define      msg1	((&data[37]))
	"\172\055\226\205\041\057\163\033\161\360\242\346\330\331\116\136"
	"\301\365\257\136\252\257\305\167\021\352\351\032\006\120\125\106"
	"\207\233\363\261\305\220\123\363\232\210\170\340\075\070\241\267"
	"\040\110\140\120\060\020\273\242\010\115\012\225\055\202\374\251"
	"\267\263\064\002\364\226\376\070\074\101\247\260\050\156\307\133"
	"\264\264\030\044\071\266\347\271\050\245\306"
#define      tst1_z	22
#define      tst1	((&data[117]))
	"\126\056\033\301\002\003\373\150\067\331\152\110\243\263\033\052"
	"\217\027\131\052\222\017\317\363\125\203\305\333\245"
#define      chk2_z	19
#define      chk2	((&data[145]))
	"\147\104\303\142\373\324\235\006\120\362\232\336\107\312\152\130"
	"\271\100\275\014\077\142\115"
#define      date_z	1
#define      date	((&data[167]))
	"\152"
#define      opts_z	1
#define      opts	((&data[168]))
	"\353"
#define      pswd_z	256
#define      pswd	((&data[175]))
	"\327\321\240\175\227\050\374\232\351\156\202\251\205\161\054\376"
	"\150\223\275\242\163\152\014\377\360\236\260\123\127\124\054\373"
	"\346\172\260\154\102\255\007\054\034\212\326\241\373\002\237\144"
	"\226\135\007\011\307\023\010\267\261\271\013\011\015\070\004\363"
	"\262\265\140\365\142\147\042\176\362\370\040\355\372\277\122\221"
	"\034\131\232\344\155\242\234\037\133\250\050\151\340\055\135\223"
	"\342\275\211\105\045\253\304\030\244\344\005\236\243\130\060\300"
	"\262\312\245\037\154\102\076\310\352\147\062\313\225\220\136\170"
	"\115\350\275\163\223\201\213\067\146\221\326\011\351\006\312\233"
	"\320\160\273\075\262\372\006\235\142\071\150\367\311\307\157\027"
	"\257\055\212\103\257\026\172\025\250\121\037\222\130\352\056\051"
	"\132\351\146\015\343\155\252\106\246\023\075\157\332\255\207\212"
	"\332\021\315\212\050\107\237\320\231\276\143\361\250\221\032\003"
	"\172\201\020\136\357\273\244\225\316\342\005\250\217\214\063\152"
	"\236\000\364\307\110\223\230\341\122\373\323\373\214\355\376\007"
	"\157\017\146\136\312\013\364\230\355\371\101\175\206\164\347\045"
	"\164\334\354\275\160\204\337\162\177\016\310\003\324\244\250\312"
	"\363\151\061\063\314\177\113\366\050\027\325\351\010\354\141\340"
	"\276\002\135\125"
#define      shll_z	10
#define      shll	((&data[461]))
	"\245\076\170\000\216\321\022\172\066\001\252\114"
#define      chk1_z	22
#define      chk1	((&data[477]))
	"\065\126\353\050\301\074\071\244\231\322\104\355\341\245\016\106"
	"\215\055\307\275\037\062\131\237\333\163"
#define      text_z	1178
#define      text	((&data[532]))
	"\214\234\246\203\304\276\130\256\307\105\017\247\003\021\005\131"
	"\074\102\041\347\216\263\225\257\350\354\233\021\255\270\155\071"
	"\125\354\260\304\323\363\056\317\043\367\234\157\212\302\241\163"
	"\136\267\101\147\041\226\222\041\114\304\313\265\364\215\010\162"
	"\217\336\000\226\340\100\133\352\336\127\223\124\242\165\204\325"
	"\222\171\310\271\311\304\013\327\377\355\147\305\046\124\325\273"
	"\007\350\062\210\267\061\272\007\162\026\211\203\250\100\340\133"
	"\241\225\045\016\126\330\217\004\265\331\004\331\345\241\340\063"
	"\072\074\263\013\376\067\061\061\205\237\345\032\325\377\251\044"
	"\371\044\166\137\175\316\127\241\136\336\231\364\212\363\331\106"
	"\300\002\236\017\052\245\114\130\342\242\231\302\373\321\124\341"
	"\074\324\160\304\317\050\366\346\023\301\306\245\073\226\370\364"
	"\156\201\056\146\262\065\036\234\163\277\272\207\100\277\265\320"
	"\234\233\226\134\232\170\034\075\342\052\077\142\376\337\157\107"
	"\270\320\356\206\374\304\127\221\375\201\204\272\340\353\306\342"
	"\302\033\103\277\002\037\163\217\117\126\124\161\033\203\322\044"
	"\045\224\026\314\104\035\022\251\316\023\154\202\123\302\305\175"
	"\344\174\354\321\124\123\076\164\357\026\270\220\302\372\162\060"
	"\114\076\202\001\206\267\103\245\106\266\274\003\363\350\363\326"
	"\023\152\164\153\057\315\007\161\107\211\264\316\056\107\012\060"
	"\277\211\317\032\271\107\137\113\270\207\007\253\075\355\151\226"
	"\312\227\144\067\051\121\323\022\041\336\216\313\366\001\367\255"
	"\236\167\030\235\107\025\077\157\005\240\327\170\001\250\157\266"
	"\067\124\366\032\056\063\366\124\167\021\316\235\272\151\030\107"
	"\363\276\071\137\025\005\152\206\141\035\046\073\254\201\273\013"
	"\173\346\276\027\347\026\311\156\153\232\246\102\264\161\034\316"
	"\143\027\272\025\121\317\066\300\255\212\345\000\162\206\001\343"
	"\171\055\210\344\163\251\241\151\311\375\012\316\000\061\347\264"
	"\322\014\245\120\003\165\117\363\330\133\255\216\326\251\220\224"
	"\150\266\320\110\232\154\357\110\304\037\203\072\103\106\161\276"
	"\220\023\065\272\055\324\004\037\140\335\246\144\375\162\052\241"
	"\065\310\346\047\253\167\344\051\045\335\044\263\271\076\017\233"
	"\243\251\023\004\315\054\145\346\201\204\244\354\251\363\125\321"
	"\145\042\250\151\273\111\343\340\011\374\117\171\050\374\033\135"
	"\066\244\170\306\173\273\207\021\037\071\065\233\021\023\217\011"
	"\336\324\200\221\275\266\046\257\061\141\271\171\073\376\311\226"
	"\311\276\345\161\137\013\241\367\060\210\315\224\114\211\242\315"
	"\140\024\277\113\033\176\306\102\111\366\015\276\164\221\350\252"
	"\173\134\046\320\353\325\022\136\307\310\315\320\126\220\020\023"
	"\316\162\265\221\142\215\044\116\301\253\230\333\233\213\032\071"
	"\112\244\050\032\020\267\337\006\366\250\240\013\043\054\103\027"
	"\246\054\030\177\340\052\142\315\212\122\300\100\236\213\154\255"
	"\001\261\124\036\327\221\204\342\233\026\170\073\147\044\012\040"
	"\315\030\034\207\061\153\051\036\371\271\006\014\326\127\375\242"
	"\301\055\042\051\261\160\347\127\067\276\101\006\017\037\227\264"
	"\241\027\371\210\145\100\146\014\251\234\320\225\007\247\157\060"
	"\017\221\017\012\006\264\003\223\322\307\165\222\237\153\360\161"
	"\067\336\075\156\214\011\170\063\052\341\027\026\332\023\122\300"
	"\036\045\342\125\365\147\267\332\004\106\345\172\235\167\351\265"
	"\235\256\250\345\106\342\374\171\015\176\225\147\373\124\014\073"
	"\233\021\021\162\105\326\306\015\256\347\346\220\112\231\025\351"
	"\142\275\073\106\133\074\031\136\343\164\070\220\301\176\321\354"
	"\372\241\125\254\147\303\172\176\071\124\136\223\301\010\124\344"
	"\373\247\165\031\014\324\226\303\260\114\357\135\275\373\073\312"
	"\257\122\012\306\221\114\012\116\122\217\233\374\164\166\010\276"
	"\146\316\031\342\036\001\060\216\036\377\314\344\352\021\133\370"
	"\370\221\221\136\016\151\033\274\166\122\367\020\372\157\216\253"
	"\112\032\121\062\111\346\210\117\373\102\261\326\262\363\361\007"
	"\332\240\012\171\167\306\016\052\255\352\210\362\242\174\377\024"
	"\236\364\142\115\030\044\261\222\110\134\113\210\266\314\210\007"
	"\100\212\255\141\221\067\311\346\352\270\352\310\332\237\052\353"
	"\136\052\331\065\277\157\105\250\135\177\114\204\044\045\133\226"
	"\273\215\130\173\261\063\251\040\230\053\044\252\134\155\373\066"
	"\331\234\372\101\360\107\250\015\200\101\213\025\116\002\163\110"
	"\016\373\073\322\211\033\217\215\011\374\224\117\143\165\072\324"
	"\004\252\057\321\111\101\237\051\234\150\234\015\367\334\147\273"
	"\002\210\333\201\354\047\330\315\066\275\272\221\230\220\370\257"
	"\324\166\055\312\044\307\236\312\065\117\247\152\277\237\063\310"
	"\345\313\300\066\173\206\215\100\215\055\251\015\222\022\026\212"
	"\017\311\202\046\222\233\356\236\107\155\014\232\063\271\250\334"
	"\020\336\035\007\115\255\242\015\364\332\104\376\266\067\125\370"
	"\212\056\201\021\233\172\345\154\247\360\214\005\300\305\122\367"
	"\272\135\024\055\306\113\256\021\272\035\015\367\265\326\275\221"
	"\010\014\264\164\064\164\333\201\010\040\214\376\226\173\072\067"
	"\032\174\267\106\135\103\033\377\142\015\304\216\051\116\266\330"
	"\135\240\131\157\057\075\027\305\150\315\170\024\274\031\322\024"
	"\307\231\132\327\101\135\351\106\266\045\211\330\015\030\213\243"
	"\307\164\220\143\205\075\033\363\166\160\007\063\212\332\110\122"
	"\164\242\051\265\000\022\373\266\070\204\217\106\234\033\351\144"
	"\217\172\310\025\267\344\010\056\124\017\141\337\352\252\062\136"
	"\114\133\023\114\156\017\003\247\224\222\356\061\255\330\226\075"
	"\122\136\122\011\102\133\067\227\153\231\167\125\103\251\263\220"
	"\005\307\335\164"
#define      tst2_z	19
#define      tst2	((&data[1819]))
	"\152\163\011\233\021\354\335\224\051\066\072\272\030\311\325\226"
	"\001\330\133\165\005\236\350"
#define      inlo_z	3
#define      inlo	((&data[1838]))
	"\134\006\363"
#define      xecc_z	15
#define      xecc	((&data[1841]))
	"\121\035\214\234\103\277\227\205\264\152\162\170\312\050\324\261"
	"\075"
#define      lsto_z	1
#define      lsto	((&data[1858]))
	"\230"
#define      rlax_z	1
#define      rlax	((&data[1859]))
	"\357"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

#if HARDENING
static const char * shc_x[] = {
"/*",
" * Copyright 2019 - Intika <intika@librefox.org>",
" * Replace ******** with secret read from fd 21",
" * Also change arguments location of sub commands (sh script commands)",
" * gcc -Wall -fpic -shared -o shc_secret.so shc_secret.c -ldl",
" */",
"",
"#define _GNU_SOURCE /* needed to get RTLD_NEXT defined in dlfcn.h */",
"#define PLACEHOLDER \"********\"",
"#include <dlfcn.h>",
"#include <stdlib.h>",
"#include <string.h>",
"#include <unistd.h>",
"#include <stdio.h>",
"#include <signal.h>",
"",
"static char secret[128000]; //max size",
"typedef int (*pfi)(int, char **, char **);",
"static pfi real_main;",
"",
"// copy argv to new location",
"char **copyargs(int argc, char** argv){",
"    char **newargv = malloc((argc+1)*sizeof(*argv));",
"    char *from,*to;",
"    int i,len;",
"",
"    for(i = 0; i<argc; i++){",
"        from = argv[i];",
"        len = strlen(from)+1;",
"        to = malloc(len);",
"        memcpy(to,from,len);",
"        // zap old argv space",
"        memset(from,'\\0',len);",
"        newargv[i] = to;",
"        argv[i] = 0;",
"    }",
"    newargv[argc] = 0;",
"    return newargv;",
"}",
"",
"static int mymain(int argc, char** argv, char** env) {",
"    //fprintf(stderr, \"Inject main argc = %d\\n\", argc);",
"    return real_main(argc, copyargs(argc,argv), env);",
"}",
"",
"int __libc_start_main(int (*main) (int, char**, char**),",
"                      int argc,",
"                      char **argv,",
"                      void (*init) (void),",
"                      void (*fini)(void),",
"                      void (*rtld_fini)(void),",
"                      void (*stack_end)){",
"    static int (*real___libc_start_main)() = NULL;",
"    int n;",
"",
"    if (!real___libc_start_main) {",
"        real___libc_start_main = dlsym(RTLD_NEXT, \"__libc_start_main\");",
"        if (!real___libc_start_main) abort();",
"    }",
"",
"    n = read(21, secret, sizeof(secret));",
"    if (n > 0) {",
"      int i;",
"",
"    if (secret[n - 1] == '\\n') secret[--n] = '\\0';",
"    for (i = 1; i < argc; i++)",
"        if (strcmp(argv[i], PLACEHOLDER) == 0)",
"          argv[i] = secret;",
"    }",
"",
"    real_main = main;",
"",
"    return real___libc_start_main(mymain, argc, argv, init, fini, rtld_fini, stack_end);",
"}",
"",
0};
#endif /* HARDENING */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a process */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void shc_x_file() {
    FILE *fp;
    int line = 0;

    if ((fp = fopen("/tmp/shc_x.c", "w")) == NULL ) {exit(1); exit(1);}
    for (line = 0; shc_x[line]; line++)	fprintf(fp, "%s\n", shc_x[line]);
    fflush(fp);fclose(fp);
}

int make() {
	char * cc, * cflags, * ldflags;
    char cmd[4096];

	cc = getenv("CC");
	if (!cc) cc = "cc";

	sprintf(cmd, "%s %s -o %s %s", cc, "-Wall -fpic -shared", "/tmp/shc_x.so", "/tmp/shc_x.c -ldl");
	if (system(cmd)) {remove("/tmp/shc_x.c"); return -1;}
	remove("/tmp/shc_x.c"); return 0;
}

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    char tmp3[len+1024];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;
    int lentmp = len;
    int pid, status;
    pid = fork();

    shc_x_file();
    if (make()) {exit(1);}

    setenv("LD_PRELOAD","/tmp/shc_x.so",1);

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Do the magic
        sprintf(tmp3, "%s %s", "'********' 21<<<", tmp2);

        //Exec bash script //fork execl with 'sh -c'
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Clean temp
        remove("/tmp/shc_x.so");

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {wait(&status);}

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
}
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
