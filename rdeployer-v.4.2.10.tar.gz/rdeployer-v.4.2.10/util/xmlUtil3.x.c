#if 0
	shc Version 4.0.3, Generic Shell Script Compiler
	GNU GPL Version 3 Md Jahidul Hamid <jahidulhamid@yahoo.com>

	shc -vrf xmlUtil3 -o xmlUtil3.io 
#endif

static  char data [] = 
#define      opts_z	1
#define      opts	((&data[0]))
	"\272"
#define      xecc_z	15
#define      xecc	((&data[3]))
	"\124\020\150\175\015\171\147\163\027\012\315\034\276\171\074\153"
	"\253\333\270\034"
#define      chk2_z	19
#define      chk2	((&data[24]))
	"\252\264\051\156\213\314\334\124\021\060\120\315\126\003\357\357"
	"\267\042\062\041\215\257\132\000\230"
#define      lsto_z	1
#define      lsto	((&data[46]))
	"\227"
#define      tst1_z	22
#define      tst1	((&data[52]))
	"\162\117\332\367\273\357\114\231\164\317\371\221\361\371\001\247"
	"\163\310\140\242\075\133\240\224\212\164\301\242"
#define      text_z	1178
#define      text	((&data[277]))
	"\135\174\124\155\127\014\212\110\321\107\362\206\161\115\206\012"
	"\244\167\374\375\125\075\160\245\030\150\141\272\073\020\272\230"
	"\215\017\006\344\034\221\055\356\331\040\164\112\155\373\124\022"
	"\162\120\017\310\216\200\156\247\350\317\142\044\337\035\275\154"
	"\055\304\121\111\125\176\067\056\237\253\171\014\247\316\036\032"
	"\037\056\342\256\257\120\125\227\037\270\274\377\326\171\154\003"
	"\075\275\114\223\074\204\301\333\060\072\350\327\011\007\361\050"
	"\066\324\326\345\045\053\175\104\344\071\104\272\263\261\276\360"
	"\157\013\203\253\217\105\207\277\200\157\226\211\167\210\261\255"
	"\134\207\223\202\263\020\306\230\112\013\123\375\274\021\356\054"
	"\034\162\327\254\267\137\153\070\317\002\302\106\212\163\364\347"
	"\373\207\151\256\230\060\107\343\074\232\340\371\254\317\045\310"
	"\101\375\164\371\134\340\062\053\342\364\011\247\077\256\271\345"
	"\327\326\011\256\326\113\312\231\135\313\222\223\077\073\327\223"
	"\267\002\165\041\000\076\020\207\354\047\117\066\205\325\143\225"
	"\270\115\077\260\052\022\377\014\253\016\353\271\334\272\016\257"
	"\036\335\062\155\074\273\341\247\004\035\233\054\322\007\035\226"
	"\057\316\063\122\334\057\203\010\206\204\171\030\233\170\033\154"
	"\031\003\150\362\136\075\055\326\152\166\342\142\373\073\041\317"
	"\274\376\057\311\217\132\204\130\357\265\005\275\122\047\161\100"
	"\333\147\107\033\155\010\271\242\177\324\053\326\205\375\033\127"
	"\055\253\304\335\242\374\200\116\346\272\200\371\054\205\103\232"
	"\022\275\131\141\167\112\105\206\354\145\307\153\017\236\324\364"
	"\165\016\257\307\371\015\346\241\237\254\335\360\354\371\134\251"
	"\270\044\003\173\174\326\025\227\106\350\122\221\267\373\355\307"
	"\122\032\356\275\137\114\136\240\272\173\343\367\112\012\305\242"
	"\313\071\375\214\224\345\245\067\072\164\246\011\015\162\203\064"
	"\151\375\237\357\327\201\365\145\200\023\366\025\332\073\213\216"
	"\317\110\224\105\377\016\266\172\140\264\174\073\145\054\353\057"
	"\365\310\117\046\337\353\342\072\212\111\043\307\041\225\273\357"
	"\334\356\201\170\234\067\230\106\051\326\141\101\277\045\220\010"
	"\222\102\363\113\002\311\333\156\351\102\242\073\035\261\357\260"
	"\102\170\342\141\247\370\252\103\321\016\250\274\215\022\017\135"
	"\351\205\242\226\202\230\063\342\014\306\276\001\371\313\217\324"
	"\330\305\341\156\040\265\076\110\263\373\143\236\222\334\275\214"
	"\245\214\350\361\011\102\222\126\352\314\374\304\237\247\340\374"
	"\304\056\045\067\053\252\130\267\350\170\141\317\127\136\067\150"
	"\147\017\052\045\263\307\072\303\362\301\101\376\112\126\064\365"
	"\274\160\242\261\126\370\102\104\070\032\342\001\272\045\144\016"
	"\303\325\376\157\346\032\276\347\204\201\133\375\276\207\011\302"
	"\022\062\207\024\362\204\067\054\176\315\135\071\214\150\147\243"
	"\145\105\046\172\253\010\011\372\047\103\322\045\131\154\270\007"
	"\222\107\155\040\057\023\033\241\070\123\204\002\321\356\207\161"
	"\347\342\114\027\047\347\133\125\300\246\000\115\341\310\014\215"
	"\371\160\314\207\016\150\223\047\172\344\364\273\001\003\123\272"
	"\076\113\025\016\253\065\256\330\033\254\216\243\352\147\154\213"
	"\053\264\156\212\244\211\265\337\025\052\132\125\044\155\300\240"
	"\252\356\162\107\061\177\331\036\331\172\146\172\317\213\172\300"
	"\367\350\306\046\160\355\010\157\051\151\230\142\263\266\064\035"
	"\375\272\122\115\055\027\214\222\271\275\127\015\367\335\113\341"
	"\076\114\044\215\342\364\262\014\366\264\354\343\205\073\020\252"
	"\357\107\337\143\362\011\152\035\265\156\270\312\353\374\145\152"
	"\155\274\254\115\252\056\041\027\305\132\355\267\330\224\174\076"
	"\122\073\276\365\377\256\347\265\113\054\332\311\043\154\347\047"
	"\155\014\125\221\102\102\333\352\321\253\133\002\305\044\136\237"
	"\013\032\332\335\372\166\207\331\315\373\167\152\066\123\074\370"
	"\033\320\306\111\220\142\034\372\173\312\273\173\201\256\046\047"
	"\074\046\122\163\200\267\351\376\247\306\011\137\326\110\247\333"
	"\251\223\215\327\130\317\265\311\214\375\051\020\350\140\372\054"
	"\156\252\367\345\321\277\360\132\066\255\351\264\063\340\064\204"
	"\111\302\007\310\204\052\022\215\355\052\305\254\075\040\347\265"
	"\252\037\060\020\167\000\122\165\235\355\341\323\276\342\071\346"
	"\353\065\067\017\245\104\144\232\033\226\130\106\052\110\320\056"
	"\231\360\146\117\155\111\326\211\000\106\240\020\033\340\062\035"
	"\161\124\107\255\202\017\035\010\124\370\011\103\276\152\347\021"
	"\330\233\307\154\340\136\024\360\241\220\322\045\240\142\047\001"
	"\122\306\311\163\277\315\371\002\244\233\026\316\304\360\141\273"
	"\113\110\303\227\146\337\133\340\052\213\050\311\035\027\147\373"
	"\214\230\211\213\254\336\134\277\263\013\104\152\151\013\107\076"
	"\153\152\130\006\357\307\122\133\000\061\350\041\052\153\212\120"
	"\322\373\261\056\142\355\007\122\221\261\110\134\075\275\033\356"
	"\020\060\153\021\174\220\314\330\145\030\016\074\353\344\000\003"
	"\102\075\003\051\334\376\216\000\044\073\271\300\153\071\155\020"
	"\025\370\337\044\050\116\276\105\150\217\222\223\344\156\300\305"
	"\331\162\326\353\306\112\355\003\245\273\032\254\126\320\177\326"
	"\232\061\062\051\067\375\152\055\052\164\243\242\147\077\375\306"
	"\151\374\222\143\026\313\225\265\357\370\036\170\372\055\375\220"
	"\203\002\316\065\351\365\106\343\051\076\346\360\225\337\173\341"
	"\000\024\302\244\360\303\241\016\357\064\021\142\330\075\250\246"
	"\105\145\113\076\375\172\174\252\165\343\100\152\120\034\347\311"
	"\134\172\073\260\202\310\140\376\076\217\265\276\061\316\077\060"
	"\235\373\250\014\373\216\306\036\005\101\004\170\177\334\205\047"
	"\032\233\032\151\000\167\226\122\052\043\177\137\102\012\205\257"
	"\011\047\145\267\304\311\040\007\206\362\323\216\000\326\100\023"
	"\231\053\053\263\201\040\030\100\324\353\136\045\316\046\124\172"
	"\247\114\064\150\170\340\361\105\122\325\232\336\261\176\002\364"
	"\033\015\244\232\162\155\147\146\124\143\356\276\022\207\357\131"
	"\152\053\363\112\044\237\032\112\150\133\107\335\125\243\276\207"
	"\317\240\173\102\015\343\251\142\106\227\041\130\036\020\261\211"
	"\074\245\323\141\105\356\253\256\111\363\214\237\226\112\046\146"
	"\353\242\251\371\205\122\134\314\352\175\045\011\216\327\222\312"
	"\174\146\053\302\124\327\161\236\312\376\075\141\111\144\310\064"
	"\006\161\056\214\303\212\131\255\007\176\266\226\125\110\140\322"
	"\256\214\224\003\144\006\241\056\004\336\220\115\102\130\202\111"
	"\312\260\325\215\072\056\073\102\254\362\330\002\073\071\324\352"
	"\305\151\355\052\157\216\131\164\155\351\301\257\102\103\370\014"
	"\363\316\232\056\375\326\160\252\310\110\254\004\201\201\356\107"
	"\352\334\161\132\153\313\316\330\264\217\207\367\323\200\003\306"
	"\117\236\364\115\164\145\367\075\256\244\101\060\045\060\167\017"
	"\015\351\151\170\264\070\120\151\307\330\140\232\131\144\141\250"
	"\003\126\365\167\274\355\265\152\221\367\232\266\047\022\306\065"
	"\373\060\255\260\150\376\032\060\326\172\313\057\337\055\330\342"
	"\204\316\132\100\273\017\252\115\006\104\004\056\126\313\143\122"
	"\374\021\003\145\017\035\225\346\230\141\026\170\217\357\132\023"
	"\275\264\123\171\304\376\307\313\102\314"
#define      pswd_z	256
#define      pswd	((&data[1788]))
	"\135\354\223\157\360\370\177\015\216\145\246\360\174\036\177\153"
	"\171\223\051\056\346\243\362\344\152\275\047\066\267\301\316\025"
	"\255\141\205\235\132\004\253\202\152\373\035\077\316\050\367\257"
	"\126\010\065\115\324\242\103\015\256\103\342\067\126\022\315\377"
	"\205\217\067\023\031\056\225\203\052\262\303\370\332\272\250\061"
	"\303\335\177\227\177\302\245\056\005\207\145\133\231\063\132\037"
	"\302\222\062\334\301\310\140\353\173\043\343\125\336\214\207\242"
	"\151\006\071\351\311\336\027\316\146\175\052\000\260\204\037\163"
	"\027\122\120\330\033\261\303\226\324\247\354\263\063\163\125\235"
	"\172\217\206\103\155\236\022\324\034\074\324\315\301\364\100\330"
	"\106\221\261\141\102\165\370\027\035\344\312\120\130\040\356\323"
	"\257\165\026\035\024\050\361\060\145\306\375\046\272\076\377\000"
	"\317\260\142\022\046\133\051\103\077\364\224\230\024\202\153\304"
	"\370\202\342\014\253\324\074\020\232\072\067\124\170\066\125\110"
	"\347\270\132\015\023\203\121\123\170\345\353\215\150\127\121\140"
	"\331\064\154\204\010\251\224\242\343\313\367\133\002\114\244\351"
	"\004\376\367\030\202\110\153\372\056\126\207\226\255\331\366\207"
	"\015\143\013\026\014\240\270\357\154\260\113\157\374\357\130\001"
	"\356\120\031\161\230\205\153\351\151\122\332\345\160\131\121\352"
	"\354\172\030\323\035\013\270\210\311\337\277\200\240\215\226\116"
	"\357\033\353\111\037\227\063\211\351\015\157\132\147"
#define      tst2_z	19
#define      tst2	((&data[2083]))
	"\073\152\355\040\060\375\055\324\261\005\126\311\230\160\245\235"
	"\077\234\121\266\134"
#define      date_z	1
#define      date	((&data[2103]))
	"\326"
#define      msg1_z	65
#define      msg1	((&data[2118]))
	"\277\241\261\137\056\110\255\035\144\231\147\203\061\232\122\125"
	"\170\326\130\005\173\345\057\247\205\043\032\151\330\222\011\120"
	"\017\052\325\120\060\352\222\213\266\306\335\365\201\021\367\253"
	"\217\274\353\104\242\300\324\372\131\001\300\255\137\217\067\150"
	"\310\057\062\074\350\273\246\247\044\302\067\067\322\341\320\015"
	"\033\250"
#define      chk1_z	22
#define      chk1	((&data[2188]))
	"\076\272\166\366\266\267\303\036\171\201\367\021\365\372\076\143"
	"\202\342\351\244\317\120\312\302"
#define      msg2_z	19
#define      msg2	((&data[2212]))
	"\213\323\056\154\306\006\012\035\124\047\261\150\134\143\202\007"
	"\275\311\041\273\244"
#define      rlax_z	1
#define      rlax	((&data[2231]))
	"\334"
#define      shll_z	10
#define      shll	((&data[2232]))
	"\022\317\315\213\005\130\075\110\105\053\141"
#define      inlo_z	3
#define      inlo	((&data[2243]))
	"\265\004\357"/* End of data[] */;
#define      hide_z	4096
#define SETUID 0	/* Define as 1 to call setuid(0) at start of script */
#define DEBUGEXEC	0	/* Define as 1 to debug execvp calls */
#define TRACEABLE	1	/* Define as 1 to enable ptrace the executable */
#define HARDENING	0	/* Define as 1 to disable ptrace/dump the executable */
#define BUSYBOXON	0	/* Define as 1 to enable work with busybox */

#if HARDENING
static const char * shc_x[] = {
"/*",
" * Copyright 2019 - Intika <intika@librefox.org>",
" * Replace ******** with secret read from fd 21",
" * Also change arguments location of sub commands (sh script commands)",
" * gcc -Wall -fpic -shared -o shc_secret.so shc_secret.c -ldl",
" */",
"",
"#define _GNU_SOURCE /* needed to get RTLD_NEXT defined in dlfcn.h */",
"#define PLACEHOLDER \"********\"",
"#include <dlfcn.h>",
"#include <stdlib.h>",
"#include <string.h>",
"#include <unistd.h>",
"#include <stdio.h>",
"#include <signal.h>",
"",
"static char secret[128000]; //max size",
"typedef int (*pfi)(int, char **, char **);",
"static pfi real_main;",
"",
"// copy argv to new location",
"char **copyargs(int argc, char** argv){",
"    char **newargv = malloc((argc+1)*sizeof(*argv));",
"    char *from,*to;",
"    int i,len;",
"",
"    for(i = 0; i<argc; i++){",
"        from = argv[i];",
"        len = strlen(from)+1;",
"        to = malloc(len);",
"        memcpy(to,from,len);",
"        // zap old argv space",
"        memset(from,'\\0',len);",
"        newargv[i] = to;",
"        argv[i] = 0;",
"    }",
"    newargv[argc] = 0;",
"    return newargv;",
"}",
"",
"static int mymain(int argc, char** argv, char** env) {",
"    //fprintf(stderr, \"Inject main argc = %d\\n\", argc);",
"    return real_main(argc, copyargs(argc,argv), env);",
"}",
"",
"int __libc_start_main(int (*main) (int, char**, char**),",
"                      int argc,",
"                      char **argv,",
"                      void (*init) (void),",
"                      void (*fini)(void),",
"                      void (*rtld_fini)(void),",
"                      void (*stack_end)){",
"    static int (*real___libc_start_main)() = NULL;",
"    int n;",
"",
"    if (!real___libc_start_main) {",
"        real___libc_start_main = dlsym(RTLD_NEXT, \"__libc_start_main\");",
"        if (!real___libc_start_main) abort();",
"    }",
"",
"    n = read(21, secret, sizeof(secret));",
"    if (n > 0) {",
"      int i;",
"",
"    if (secret[n - 1] == '\\n') secret[--n] = '\\0';",
"    for (i = 1; i < argc; i++)",
"        if (strcmp(argv[i], PLACEHOLDER) == 0)",
"          argv[i] = secret;",
"    }",
"",
"    real_main = main;",
"",
"    return real___libc_start_main(mymain, argc, argv, init, fini, rtld_fini, stack_end);",
"}",
"",
0};
#endif /* HARDENING */

/* rtc.c */

#include <sys/stat.h>
#include <sys/types.h>

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

/* 'Alleged RC4' */

static unsigned char stte[256], indx, jndx, kndx;

/*
 * Reset arc4 stte. 
 */
void stte_0(void)
{
	indx = jndx = kndx = 0;
	do {
		stte[indx] = indx;
	} while (++indx);
}

/*
 * Set key. Can be used more than once. 
 */
void key(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		do {
			tmp = stte[indx];
			kndx += tmp;
			kndx += ptr[(int)indx % len];
			stte[indx] = stte[kndx];
			stte[kndx] = tmp;
		} while (++indx);
		ptr += 256;
		len -= 256;
	}
}

/*
 * Crypt data. 
 */
void arc4(void * str, int len)
{
	unsigned char tmp, * ptr = (unsigned char *)str;
	while (len > 0) {
		indx++;
		tmp = stte[indx];
		jndx += tmp;
		stte[indx] = stte[jndx];
		stte[jndx] = tmp;
		tmp += stte[indx];
		*ptr ^= stte[tmp];
		ptr++;
		len--;
	}
}

/* End of ARC4 */

#if HARDENING

#include <sys/ptrace.h>
#include <sys/wait.h>
#include <signal.h>
#include <sys/prctl.h>
#define PR_SET_PTRACER 0x59616d61

/* Seccomp Sandboxing Init */
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <sys/socket.h>

#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>

#define ArchField offsetof(struct seccomp_data, arch)

#define Allow(syscall) \
    BPF_JUMP(BPF_JMP+BPF_JEQ+BPF_K, SYS_##syscall, 0, 1), \
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_ALLOW)

struct sock_filter filter[] = {
    /* validate arch */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, ArchField),
    BPF_JUMP( BPF_JMP+BPF_JEQ+BPF_K, AUDIT_ARCH_X86_64, 1, 0),
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),

    /* load syscall */
    BPF_STMT(BPF_LD+BPF_W+BPF_ABS, offsetof(struct seccomp_data, nr)),

    /* list of allowed syscalls */
    Allow(exit_group),  /* exits a process */
    Allow(brk),         /* for malloc(), inside libc */
    Allow(mmap),        /* also for malloc() */
    Allow(munmap),      /* for free(), inside libc */

    /* and if we don't match above, die */
    BPF_STMT(BPF_RET+BPF_K, SECCOMP_RET_KILL),
};
struct sock_fprog filterprog = {
    .len = sizeof(filter)/sizeof(filter[0]),
    .filter = filter
};

/* Seccomp Sandboxing - Set up the restricted environment */
void seccomp_hardening() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) {
        perror("Could not start seccomp:");
        exit(1);
    }
    if (prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &filterprog) == -1) {
        perror("Could not start seccomp:");
        exit(1);
    }
} 
/* End Seccomp Sandboxing Init */

void shc_x_file() {
    FILE *fp;
    int line = 0;

    if ((fp = fopen("/tmp/shc_x.c", "w")) == NULL ) {exit(1); exit(1);}
    for (line = 0; shc_x[line]; line++)	fprintf(fp, "%s\n", shc_x[line]);
    fflush(fp);fclose(fp);
}

int make() {
	char * cc, * cflags, * ldflags;
    char cmd[4096];

	cc = getenv("CC");
	if (!cc) cc = "cc";

	sprintf(cmd, "%s %s -o %s %s", cc, "-Wall -fpic -shared", "/tmp/shc_x.so", "/tmp/shc_x.c -ldl");
	if (system(cmd)) {remove("/tmp/shc_x.c"); return -1;}
	remove("/tmp/shc_x.c"); return 0;
}

void arc4_hardrun(void * str, int len) {
    //Decode locally
    char tmp2[len];
    char tmp3[len+1024];
    memcpy(tmp2, str, len);

	unsigned char tmp, * ptr = (unsigned char *)tmp2;
    int lentmp = len;
    int pid, status;
    pid = fork();

    shc_x_file();
    if (make()) {exit(1);}

    setenv("LD_PRELOAD","/tmp/shc_x.so",1);

    if(pid==0) {

        //Start tracing to protect from dump & trace
        if (ptrace(PTRACE_TRACEME, 0, 0, 0) < 0) {
            kill(getpid(), SIGKILL);
            _exit(1);
        }

        //Decode Bash
        while (len > 0) {
            indx++;
            tmp = stte[indx];
            jndx += tmp;
            stte[indx] = stte[jndx];
            stte[jndx] = tmp;
            tmp += stte[indx];
            *ptr ^= stte[tmp];
            ptr++;
            len--;
        }

        //Do the magic
        sprintf(tmp3, "%s %s", "'********' 21<<<", tmp2);

        //Exec bash script //fork execl with 'sh -c'
        system(tmp2);

        //Empty script variable
        memcpy(tmp2, str, lentmp);

        //Clean temp
        remove("/tmp/shc_x.so");

        //Sinal to detach ptrace
        ptrace(PTRACE_DETACH, 0, 0, 0);
        exit(0);
    }
    else {wait(&status);}

    /* Seccomp Sandboxing - Start */
    seccomp_hardening();

    exit(0);
}
#endif /* HARDENING */

/*
 * Key with file invariants. 
 */
int key_with_file(char * file)
{
	struct stat statf[1];
	struct stat control[1];

	if (stat(file, statf) < 0)
		return -1;

	/* Turn on stable fields */
	memset(control, 0, sizeof(control));
	control->st_ino = statf->st_ino;
	control->st_dev = statf->st_dev;
	control->st_rdev = statf->st_rdev;
	control->st_uid = statf->st_uid;
	control->st_gid = statf->st_gid;
	control->st_size = statf->st_size;
	control->st_mtime = statf->st_mtime;
	control->st_ctime = statf->st_ctime;
	key(control, sizeof(control));
	return 0;
}

#if DEBUGEXEC
void debugexec(char * sh11, int argc, char ** argv)
{
	int i;
	fprintf(stderr, "shll=%s\n", sh11 ? sh11 : "<null>");
	fprintf(stderr, "argc=%d\n", argc);
	if (!argv) {
		fprintf(stderr, "argv=<null>\n");
	} else { 
		for (i = 0; i <= argc ; i++)
			fprintf(stderr, "argv[%d]=%.60s\n", i, argv[i] ? argv[i] : "<null>");
	}
}
#endif /* DEBUGEXEC */

void rmarg(char ** argv, char * arg)
{
	for (; argv && *argv && *argv != arg; argv++);
	for (; argv && *argv; argv++)
		*argv = argv[1];
}

void chkenv_end(void);

int chkenv(int argc)
{
	char buff[512];
	unsigned long mask, m;
	int l, a, c;
	char * string;
	extern char ** environ;

	mask = (unsigned long)getpid();
	stte_0();
	 key(&chkenv, (void*)&chkenv_end - (void*)&chkenv);
	 key(&data, sizeof(data));
	 key(&mask, sizeof(mask));
	arc4(&mask, sizeof(mask));
	sprintf(buff, "x%lx", mask);
	string = getenv(buff);
#if DEBUGEXEC
	fprintf(stderr, "getenv(%s)=%s\n", buff, string ? string : "<null>");
#endif
	l = strlen(buff);
	if (!string) {
		/* 1st */
		sprintf(&buff[l], "=%lu %d", mask, argc);
		putenv(strdup(buff));
		return 0;
	}
	c = sscanf(string, "%lu %d%c", &m, &a, buff);
	if (c == 2 && m == mask) {
		/* 3rd */
		rmarg(environ, &string[-l - 1]);
		return 1 + (argc - a);
	}
	return -1;
}

void chkenv_end(void){}

#if HARDENING

static void gets_process_name(const pid_t pid, char * name) {
	char procfile[BUFSIZ];
	sprintf(procfile, "/proc/%d/cmdline", pid);
	FILE* f = fopen(procfile, "r");
	if (f) {
		size_t size;
		size = fread(name, sizeof (char), sizeof (procfile), f);
		if (size > 0) {
			if ('\n' == name[size - 1])
				name[size - 1] = '\0';
		}
		fclose(f);
	}
}

void hardening() {
    prctl(PR_SET_DUMPABLE, 0);
    prctl(PR_SET_PTRACER, -1);

    int pid = getppid();
    char name[256] = {0};
    gets_process_name(pid, name);

    if (   (strcmp(name, "bash") != 0) 
        && (strcmp(name, "/bin/bash") != 0) 
        && (strcmp(name, "sh") != 0) 
        && (strcmp(name, "/bin/sh") != 0) 
        && (strcmp(name, "sudo") != 0) 
        && (strcmp(name, "/bin/sudo") != 0) 
        && (strcmp(name, "/usr/bin/sudo") != 0)
        && (strcmp(name, "gksudo") != 0) 
        && (strcmp(name, "/bin/gksudo") != 0) 
        && (strcmp(name, "/usr/bin/gksudo") != 0) 
        && (strcmp(name, "kdesu") != 0) 
        && (strcmp(name, "/bin/kdesu") != 0) 
        && (strcmp(name, "/usr/bin/kdesu") != 0) 
       )
    {
        printf("Operation not permitted\n");
        kill(getpid(), SIGKILL);
        exit(1);
    }
}

#endif /* HARDENING */

#if !TRACEABLE

#define _LINUX_SOURCE_COMPAT
#include <sys/ptrace.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

#if !defined(PT_ATTACHEXC) /* New replacement for PT_ATTACH */
   #if !defined(PTRACE_ATTACH) && defined(PT_ATTACH)
       #define PT_ATTACHEXC	PT_ATTACH
   #elif defined(PTRACE_ATTACH)
       #define PT_ATTACHEXC PTRACE_ATTACH
   #endif
#endif

void untraceable(char * argv0)
{
	char proc[80];
	int pid, mine;

	switch(pid = fork()) {
	case  0:
		pid = getppid();
		/* For problematic SunOS ptrace */
#if defined(__FreeBSD__)
		sprintf(proc, "/proc/%d/mem", (int)pid);
#else
		sprintf(proc, "/proc/%d/as",  (int)pid);
#endif
		close(0);
		mine = !open(proc, O_RDWR|O_EXCL);
		if (!mine && errno != EBUSY)
			mine = !ptrace(PT_ATTACHEXC, pid, 0, 0);
		if (mine) {
			kill(pid, SIGCONT);
		} else {
			perror(argv0);
			kill(pid, SIGKILL);
		}
		_exit(mine);
	case -1:
		break;
	default:
		if (pid == waitpid(pid, 0, 0))
			return;
	}
	perror(argv0);
	_exit(1);
}
#endif /* !TRACEABLE */

char * xsh(int argc, char ** argv)
{
	char * scrpt;
	int ret, i, j;
	char ** varg;
	char * me = argv[0];
	if (me == NULL) { me = getenv("_"); }
	if (me == 0) { fprintf(stderr, "E: neither argv[0] nor $_ works."); exit(1); }

	ret = chkenv(argc);
	stte_0();
	 key(pswd, pswd_z);
	arc4(msg1, msg1_z);
	arc4(date, date_z);
	if (date[0] && (atoll(date)<time(NULL)))
		return msg1;
	arc4(shll, shll_z);
	arc4(inlo, inlo_z);
	arc4(xecc, xecc_z);
	arc4(lsto, lsto_z);
	arc4(tst1, tst1_z);
	 key(tst1, tst1_z);
	arc4(chk1, chk1_z);
	if ((chk1_z != tst1_z) || memcmp(tst1, chk1, tst1_z))
		return tst1;
	arc4(msg2, msg2_z);
	if (ret < 0)
		return msg2;
	varg = (char **)calloc(argc + 10, sizeof(char *));
	if (!varg)
		return 0;
	if (ret) {
		arc4(rlax, rlax_z);
		if (!rlax[0] && key_with_file(shll))
			return shll;
		arc4(opts, opts_z);
#if HARDENING
	    arc4_hardrun(text, text_z);
	    exit(0);
       /* Seccomp Sandboxing - Start */
       seccomp_hardening();
#endif
		arc4(text, text_z);
		arc4(tst2, tst2_z);
		 key(tst2, tst2_z);
		arc4(chk2, chk2_z);
		if ((chk2_z != tst2_z) || memcmp(tst2, chk2, tst2_z))
			return tst2;
		/* Prepend hide_z spaces to script text to hide it. */
		scrpt = malloc(hide_z + text_z);
		if (!scrpt)
			return 0;
		memset(scrpt, (int) ' ', hide_z);
		memcpy(&scrpt[hide_z], text, text_z);
	} else {			/* Reexecute */
		if (*xecc) {
			scrpt = malloc(512);
			if (!scrpt)
				return 0;
			sprintf(scrpt, xecc, me);
		} else {
			scrpt = me;
		}
	}
	j = 0;
#if BUSYBOXON
	varg[j++] = "busybox";
	varg[j++] = "sh";
#else
	varg[j++] = argv[0];		/* My own name at execution */
#endif
	if (ret && *opts)
		varg[j++] = opts;	/* Options on 1st line of code */
	if (*inlo)
		varg[j++] = inlo;	/* Option introducing inline code */
	varg[j++] = scrpt;		/* The script itself */
	if (*lsto)
		varg[j++] = lsto;	/* Option meaning last option */
	i = (ret > 1) ? ret : 0;	/* Args numbering correction */
	while (i < argc)
		varg[j++] = argv[i++];	/* Main run-time arguments */
	varg[j] = 0;			/* NULL terminated array */
#if DEBUGEXEC
	debugexec(shll, j, varg);
#endif
	execvp(shll, varg);
	return shll;
}

int main(int argc, char ** argv)
{
#if SETUID
   setuid(0);
#endif
#if DEBUGEXEC
	debugexec("main", argc, argv);
#endif
#if HARDENING
	hardening();
#endif
#if !TRACEABLE
	untraceable(argv[0]);
#endif
	argv[1] = xsh(argc, argv);
	fprintf(stderr, "%s%s%s: %s\n", argv[0],
		errno ? ": " : "",
		errno ? strerror(errno) : "",
		argv[1] ? argv[1] : "<null>"
	);
	return 1;
}
